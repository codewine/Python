import requests
import json

def lambda_handler(event, context):

    access_token = event['payload']['accessToken']

    if event['header']['namespace'] == 'Alexa.ConnectedHome.Discovery':

        return handleDiscovery(context, event)

    elif event['header']['namespace'] == 'Alexa.ConnectedHome.Control':

        return handleControl(context, event)


def handleDiscovery(context, event):
    payload = ''

    header = {

        "namespace": "Alexa.ConnectedHome.Discovery",
        "name": "DiscoverAppliancesResponse",
        "payloadVersion": "2"
        }

    if event['header']['name'] == 'DiscoverAppliancesRequest':
        payload = {

            "discoveredAppliances":[

                {
                    "applianceId":"device001",
                    "manufacturerName":"lawTest",
                    "modelName":"lamp",
                    "version":"1.1",
                    "friendlyName":"Smart Home Virtual Device",
                    "friendlyDescription":"Virtual Device for the Sample Hello World Skill",
                    "isReachable":True,
                    "actions":[
                        "turnOn",
                        "turnOff"
                    ],

                    "additionalApplianceDetails":{

                        "extraDetail1":"optionalDetailForSkillAdapterToReferenceThisDevice",

                        "extraDetail2":"There can be multiple entries",

                        "extraDetail3":"but they should only be used for reference purposes.",

                        "extraDetail4":"This is not a suitable place to maintain current device state"

                    }

                }

            ]

        }

    return {'header': header, 'payload': payload}



def handleControl(context, event):

    print(context)
    payload = ''

    # device_id = event['payload']['appliance']['applianceId']
    # message_id = event['header']['messageId']

    # if event['header']['name'] == 'TurnOnRequest':

    #     payload = { }


    # header = {

    #     "namespace":"Alexa.ConnectedHome.Control",

    #     "name":"TurnOnConfirmation",

    #     "payloadVersion":"2",

    #     "messageId": message_id

    #     }
    url = 'http://dev-comen.xqopen.net:8081/comen/v1/devices/PRI20170617172725RFpGHjFWM/ctrl'
    values = {' contextId':'',
                'msg':'eec93b6c8cb8ec9fede6820fa76313dcdc1c8452592d177e39d415482e4bcf9a'
             }
    data = json.dumps(values)
    print (data)
    headers = {'Accept-Language':'zh-Hans-CN;q=1, en-CN;q=0.9',
                'Content-Type':'application/json',
                'User-Agent':'comen/1.0.1706210 (iPhone; iOS 10.3.2; Scale/2.00)',
                'language':'zh-CN',
                'token':'TOKEN20170619114613RGxVCjgWF',
                'userId':'PRI20170420115533RavTQ2r29',
                }
    req = requests.post(url,data,headers=headers)
    the_page = req.text
    print(the_page)

    return the_page

